package elrincon.org.web.service;

public class HolaMundo {
	public float addValue(float value) {
		return (value + 10);
	}

	public float subtractValue(float value) {
		return (value - 10);
	}
}
