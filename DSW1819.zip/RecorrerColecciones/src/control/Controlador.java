package control;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Controlador
 */
@WebServlet("/logica")
public class Controlador extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Controlador() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		ServletContext sc = request.getServletContext();

		Object[] array = { "Jonny", 28, 'M' };
		sc.setAttribute("array", array);

		ArrayList<Object> lista = new ArrayList<Object>();
		lista.add("Jonny");
		lista.add(28);
		lista.add('M');
		sc.setAttribute("lista", lista);

		HashMap<Object, Object> mapa = new HashMap<Object, Object>();
		mapa.put("nombre", "Jonny");
		mapa.put("edad", 28);
		mapa.put("genero", 'M');
		sc.setAttribute("mapa", mapa);

		String opcion = request.getParameter("opcion");

		String rutaJSP = "";
		switch (opcion) {
		case "con":
			rutaJSP = "/jsp/jstl.jsp";
			break;
		case "sin":
			rutaJSP = "/jsp/no_jstl.jsp";
			break;
		}

		RequestDispatcher rd = sc.getRequestDispatcher(rutaJSP);
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
