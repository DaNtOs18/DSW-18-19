package control;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Utilidad
 */
@WebServlet("/Utilidad")
public class Utilidad extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Utilidad() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();

		int contador = 0;
		this.getServletContext().getAttribute("contador");
		
		//session.setAttribute("contador", contador);

		ArrayList<Object> lista = new ArrayList<Object>();

		if (session.getAttribute("usuario") == null)
			session.setAttribute("usuario", "Jonny");
		if (session.getAttribute("lista") == null)
			session.setAttribute("lista", lista);
		System.out.println("ID de sesi�n: " + session.getId());
		/*Cookie[] cookies = request.getCookies();
		for (Cookie cookie : cookies) {
			System.out.println(cookie.getName() + " : " + cookie.getValue());
		}*/

		//this.getServletContext().getRequestDispatcher("/Servlet2").forward(request, response);
		System.out.println("Sigo en utilidad");

		String op1 = request.getParameter("a");
		String op2 = request.getParameter("b");
		int suma = 0;

		try {
			suma = Integer.parseInt(op1) + Integer.parseInt(op2);
			response.getWriter().append("La suma es: " + suma);
		} catch (NumberFormatException e) {
			response.getWriter().append("Error de formato");
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		System.out.println("Inicializando servlet...");
		// String nombre = getInitParameter("nombre");
		String pais = getServletContext().getInitParameter("Pais");
		// System.out.println(nombre);
		System.out.println(pais);
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
	}

}
