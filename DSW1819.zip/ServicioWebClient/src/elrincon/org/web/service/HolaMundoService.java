/**
 * HolaMundoService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package elrincon.org.web.service;

public interface HolaMundoService extends javax.xml.rpc.Service {
    public java.lang.String getHolaMundoAddress();

    public elrincon.org.web.service.HolaMundo getHolaMundo() throws javax.xml.rpc.ServiceException;

    public elrincon.org.web.service.HolaMundo getHolaMundo(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
