package elrincon.org.web.service;

public class HolaMundoProxy implements elrincon.org.web.service.HolaMundo {
  private String _endpoint = null;
  private elrincon.org.web.service.HolaMundo holaMundo = null;
  
  public HolaMundoProxy() {
    _initHolaMundoProxy();
  }
  
  public HolaMundoProxy(String endpoint) {
    _endpoint = endpoint;
    _initHolaMundoProxy();
  }
  
  private void _initHolaMundoProxy() {
    try {
      holaMundo = (new elrincon.org.web.service.HolaMundoServiceLocator()).getHolaMundo();
      if (holaMundo != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)holaMundo)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)holaMundo)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (holaMundo != null)
      ((javax.xml.rpc.Stub)holaMundo)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public elrincon.org.web.service.HolaMundo getHolaMundo() {
    if (holaMundo == null)
      _initHolaMundoProxy();
    return holaMundo;
  }
  
  public float addValue(float value) throws java.rmi.RemoteException{
    if (holaMundo == null)
      _initHolaMundoProxy();
    return holaMundo.addValue(value);
  }
  
  public float subtractValue(float value) throws java.rmi.RemoteException{
    if (holaMundo == null)
      _initHolaMundoProxy();
    return holaMundo.subtractValue(value);
  }
  
  
}