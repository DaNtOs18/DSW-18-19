package modelo;

import java.time.LocalDate;

public class Intento {

	private LocalDate tiempo;
	private int intento;
	private int numJugado;
	private String mensaje;

	public LocalDate getTiempo() {
		return tiempo;
	}

	public void setTiempo(LocalDate tiempo) {
		this.tiempo = tiempo;
	}

	public int getIntento() {
		return intento;
	}

	public void setIntento(int intento) {
		this.intento = intento;
	}

	public int getNumJugado() {
		return numJugado;
	}

	public void setNumJugado(int numJugado) {
		this.numJugado = numJugado;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public Intento() {
		super();
		
	}

	public Intento(LocalDate tiempo, int intento, int numJugado, String mensaje) {
		super();
		this.tiempo = tiempo;
		this.intento = intento;
		this.numJugado = numJugado;
		this.mensaje = mensaje;
	}

	@Override
	public String toString() {
		return "Intento [tiempo=" + tiempo + ", intento=" + intento + ", numJugado=" + numJugado + ", mensaje="
				+ mensaje + "]";
	}
}
