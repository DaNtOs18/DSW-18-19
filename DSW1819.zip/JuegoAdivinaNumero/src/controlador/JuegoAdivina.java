package controlador;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import modelo.Intento;

/**
 * Servlet implementation class JuegoAdivina
 */
@WebServlet("/logica")
public class JuegoAdivina extends HttpServlet {

	private ArrayList<Intento> intentos;

	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public JuegoAdivina() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession se = request.getSession();

		String rutaJSP = "/jsp/juego.jsp";
		intentos = new ArrayList<Intento>();
		intentos = (ArrayList<Intento>) se.getAttribute("intentos");

		int entCtx = 0;

		if (request.getParameter("iniciar") != null) {
			int maximo = Integer.parseInt(request.getParameter("max"));
			se.setAttribute("maxi", maximo);
			int maxCtx = Integer.parseInt(se.getAttribute("maxi").toString());

			int minimo = Integer.parseInt(request.getParameter("min"));
			se.setAttribute("mini", minimo);
			int minCtx = Integer.parseInt(se.getAttribute("mini").toString());

			int aleatorio = (int) (Math.random() * maximo + minimo);
			se.setAttribute("rnd", aleatorio);

			System.out.println(aleatorio);

		}

		if (request.getParameter("prueba") != null) {

			int entrada = Integer.parseInt(request.getParameter("numero"));
			entCtx = entrada;

			int rnd = Integer.parseInt(se.getAttribute("rnd").toString());

			if (intentos == null) // primera vez ...
			{
				intentos = new ArrayList<Intento>();
				se.setAttribute("intentos", intentos);
			}

			int i = 0;
			LocalDate tiempo = LocalDate.now();
			int att = (intentos.size() + 1);
			int numJugado = entCtx;
			String mensaje;

			if (rnd == entCtx) {
				Intento intento = new Intento(tiempo, att++, numJugado, "Correcto");
				intentos.add(intento);

				System.out.println("Correcto. Lo has conseguido en: " + intentos.size() + " intentos.");

				request.getParameter("prueba");
				

				/*
				 * for (Intento intento2 : intentos) { System.out.println(intentos.get(i)); i++;
				 * }
				 */

				// se.invalidate();
			}

			else {

				if (rnd < entCtx) {

					Intento intento = new Intento(tiempo, att++, numJugado, "M�s bajo");
					intentos.add(intento);
					System.out.println(intento);
					// System.out.println("M�s bajo");
				}

				else {

					Intento intento = new Intento(tiempo, att++, numJugado, "M�s alto");
					intentos.add(intento);
					System.out.println(intento);
					// System.out.println("M�s alto");
				}
			}

			/*
			 * if (request.getParameter("prueba") != null) { int rnd =
			 * Integer.parseInt(se.getAttribute("rnd").toString());
			 * 
			 * // se.setAttribute("entrada", entrada);
			 * 
			 * do { intento++; int entrada =
			 * Integer.parseInt(request.getParameter("numero")); entCtx = entrada;
			 * 
			 * // entCtx = Integer.parseInt(se.getAttribute("entrada").toString());
			 * 
			 * if (rnd < entCtx) {
			 * 
			 * System.out.println("M�s bajo"); }
			 * 
			 * else if (rnd > entCtx) {
			 * 
			 * System.out.println("M�s alto"); }
			 * 
			 * else if (rnd == entCtx) {
			 * 
			 * System.out.println("Correcto. Lo has conseguido en " + intento +
			 * " intentos.");
			 * 
			 * } System.out.println("hello"); } while (rnd != entCtx &&
			 * request.getParameter("prueba") == "�Prueba!");
			 * 
			 * }
			 */

			// System.out.println("Introduce un n�mero, por favor...");

		}
		RequestDispatcher rd = request.getServletContext().getRequestDispatcher(rutaJSP);
		rd.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);

	}
}
