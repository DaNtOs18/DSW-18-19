package modelo;

public class Contador {
	private int contador;

	public int getContador() {
		return contador;
	}

	public void setContador(int contador) {
		this.contador = contador;
	}

	public void incrementar() {
		this.contador++;
	}

	@Override
	public String toString() {
		return "El contador de sesiones est� a: " + contador;
	}
}
