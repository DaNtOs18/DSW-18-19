package control;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import modelo.Contador;

/**
 * Servlet implementation class Util
 */
@WebServlet("/contadores")
public class Util extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Util() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession sesion = request.getSession();

		Contador contadorSe = (Contador) sesion.getAttribute("contadorSesion");
		ServletContext contexto = this.getServletContext();
		Contador contaContexto = (Contador) contexto.getAttribute("contadorContexto");
		
		if (contadorSe == null) {
			System.out.println("Creando variable de sesi�n..");
			contadorSe = new Contador();
			sesion.setAttribute("contadorSesion", contadorSe);
		}
		
		if (contaContexto == null) {
			System.out.println("Creando variable de contexto..");
			contaContexto = new Contador();
			contexto.setAttribute("contadorContexto", contaContexto);
		}
		
		contadorSe.incrementar();
		contaContexto.incrementar();
		response.getWriter().append("SESIONES: " + contadorSe); 
		response.getWriter().append("\r Contador contexto  : " + contaContexto.getContador());

		

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
